import json, os, pwd, re, subprocess, sys, time
from pathlib import Path
from PyQt6.QtCore import QSize, Qt, QTimer
from PyQt6.QtGui import QColor, QFont, QIcon, QPalette, QWindow, QKeySequence, QShortcut, QSyntaxHighlighter, QTextCharFormat
from PyQt6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFontDialog, QGroupBox,
    QHBoxLayout, QInputDialog, QLabel, QLineEdit, QListWidget, QMainWindow,
    QMessageBox, QPlainTextEdit, QPushButton, QScrollArea, QSplitter,
    QMenuBar, QTabWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget,
)
from gentoolcfg.cli import (
    CfgStore, PROTECTED_KEYS, filter_make_conf, generate_diff_patch,
    list_trashed_patches, restore_trashed_patch, rotate_backup,
    trash_or_delete_patch, write_one,
)
from gentoolcfg.extras import (
    KERNEL_CFG_DIR, apply_env_rollback, cascade_delete_env, find_env_refs, kernel_summary, list_env_rollbacks, list_backups, list_kernel_snippets,
    read_build_monitor, unified_diff_lines,
)
from gentoolcfg.portage_io import ENV_PROFILES_DIR, ensure_gentoo_os

def _fmt(color: str, bold: bool = False) -> QTextCharFormat:
    f = QTextCharFormat(); f.setForeground(QColor(color))
    if bold: f.setFontWeight(700)
    return f

class MakeConfHighlighter(QSyntaxHighlighter):
    def highlightBlock(self, text: str) -> None:
        if text.lstrip().startswith("#"): self.setFormat(0, len(text), _fmt("#6272a4")); return
        for m in re.finditer(r"^\s*([A-Za-z_][A-Za-z0-9_]*)", text): self.setFormat(m.start(1), m.end(1) - m.start(1), _fmt("#ff5555", True))
        for m in re.finditer(r"=", text): self.setFormat(m.start(), 1, _fmt("#f1fa8c", True))
        for m in re.finditer(r"['\"]", text): self.setFormat(m.start(), 1, _fmt("#50fa7b", True))
        for m in re.finditer(r"(?<=[\s'\"])-[A-Za-z0-9_+.:=-]+", text): self.setFormat(m.start(), m.end() - m.start(), _fmt("#55aaff", True))

class DiffHighlighter(QSyntaxHighlighter):
    def highlightBlock(self, text: str) -> None:
        if text.startswith(("+++", "---")): self.setFormat(0, len(text), _fmt("#8be9fd", True))
        elif text.startswith("@@"): self.setFormat(0, len(text), _fmt("#bd93f9", True))
        elif text.startswith("+"): self.setFormat(0, len(text), _fmt("#50fa7b", True))
        elif text.startswith("-"): self.setFormat(0, len(text), _fmt("#ff5555", True))

def _flat_link(text: str, fn) -> QPushButton:
    b = QPushButton(text); b.setFlat(True); b.setCursor(Qt.CursorShape.PointingHandCursor)
    b.setStyleSheet("QPushButton { border: none; padding: 2px 6px; color: #3daee9; font-weight: 600; } QPushButton:hover { text-decoration: underline; }")
    b.clicked.connect(fn); return b

def _icon_btn(icon_names: tuple[str, ...], fallback: str, tip: str, fn) -> QPushButton:
    b = QPushButton(); b.setToolTip(tip); b.setIconSize(QSize(18, 18)); b.setFixedSize(28, 28)
    b.setStyleSheet("QPushButton { padding: 0px; }")
    for nm in icon_names:
        ic = QIcon.fromTheme(nm)
        if not ic.isNull(): b.setIcon(ic); break
    if b.icon().isNull(): b.setText(fallback)
    b.clicked.connect(fn); return b

def _ui_cfg_path() -> Path:
    return Path("/etc/portage/.gentoolcfg-ui.json")

def _compact_btn(text: str, fn) -> QPushButton:
    b = QPushButton(text); b.setStyleSheet("padding: 2px 8px;"); b.clicked.connect(fn); return b

class GentoolCfgQt(QMainWindow):
    def __init__(self) -> None:
        super().__init__(); self.setWindowTitle("gentoolcfg 2.1.0"); self.resize(1220, 760)
        self.store = CfgStore(); self.cur_pkg = None; self.active_env = ""; self.active_kcfg = ""
        cfg = json.loads(_ui_cfg_path().read_text()) if _ui_cfg_path().is_file() else {}
        self.ui_dark = bool(cfg["ui_dark"]) if "ui_dark" in cfg else _detect_kde_dark()

        self.ui_font = QFont(cfg.get("ui_font_family", "Sans Serif"), int(cfg.get("ui_font_size", 10)))
        mb = self.menuBar()
        m_set = mb.addMenu("Settings")
        self.act_dark = m_set.addAction("Switch to Light Theme" if self.ui_dark else "Switch to Dark Theme")
        self.act_dark.setCheckable(True); self.act_dark.setChecked(self.ui_dark); self.act_dark.toggled.connect(self._mon_theme)
        a_fnt = m_set.addAction("Application Font...", self._mon_font_pick); a_fnt.setIcon(QIcon.fromTheme("preferences-desktop-font"))
        m_abt = mb.addMenu("About")
        a_abt = m_abt.addAction("About gentoolcfg", lambda: QMessageBox.about(self, "About gentoolcfg", "gentoolcfg 2.1.0\nUnified Gentoo Portage, Kernel & Build Monitor Configurator\nWakStab Project — MIT License"))
        a_abt.setIcon(QIcon.fromTheme("help-about"))
        self.top_tabs = QTabWidget(); self.setCentralWidget(self.top_tabs)
        self.top_tabs.currentChanged.connect(self._on_top_tab)
        root = QWidget(); lay = QVBoxLayout(root); lay.setContentsMargins(4, 4, 4, 4)
        self.top_tabs.addTab(root, QIcon.fromTheme("preferences-system"), "Portage Config")
        self.qp_tab = QWidget(); self.qp_lay = QVBoxLayout(self.qp_tab); self.qp_lay.setContentsMargins(0, 0, 0, 0)
        self.qp_proc = None; self.qp_embedded = False
        self.qp_status = QLabel("Click to load QParted Partition Manager...")
        self.qp_lay.addWidget(self.qp_status)
        self.top_tabs.addTab(self.qp_tab, QIcon.fromTheme("drive-harddisk"), "Partition Manager")
        sp = QSplitter(Qt.Orientation.Horizontal); lay.addWidget(sp, 1)
        lw = QWidget(); ll = QVBoxLayout(lw); sp.addWidget(lw)
        self.q_in = QLineEdit(); self.q_in.setPlaceholderText("Filter packages..."); self.q_in.textChanged.connect(self._tree); ll.addWidget(self.q_in)
        self.tree = QTreeWidget(); self.tree.setHeaderHidden(True); self.tree.itemSelectionChanged.connect(self._sel); ll.addWidget(self.tree, 1)
        rw = QWidget(); rl = QVBoxLayout(rw); sp.addWidget(rw); sp.setSizes([350, 870])
        self.hdr = QLabel("Select a package on the left."); rl.addWidget(self.hdr)
        self.nb = QTabWidget(); self.nb.setUsesScrollButtons(True); rl.addWidget(self.nb, 1)
        uw = QWidget(); ul = QVBoxLayout(uw); ubar = QHBoxLayout()
        self.uf = QLineEdit(); self.uf.setPlaceholderText("Filter USE..."); self.uf.textChanged.connect(self._use)
        ubar.addWidget(self.uf); ubar.addWidget(_icon_btn(("view-refresh", "reload"), "↻", "Refresh", self._reload)); ubar.addWidget(_icon_btn(("document-save",), "💾", "Save USE", lambda: self._save_sc("use"))); ul.addLayout(ubar)
        self.usc = QScrollArea(); self.usc.setWidgetResizable(True); self.ubox = QWidget(); self.ul_in = QVBoxLayout(self.ubox); self.ul_in.setSpacing(2); self.ul_in.setContentsMargins(4, 4, 4, 4); self.usc.setWidget(self.ubox); ul.addWidget(self.usc, 1); self.nb.addTab(uw, "USE")
        ew = QWidget(); el = QHBoxLayout(ew); el_l = QVBoxLayout()
        self.esc = QScrollArea(); self.esc.setWidgetResizable(True); self.ebox = QWidget(); self.el_in = QVBoxLayout(self.ebox); self.el_in.setSpacing(1); self.el_in.setContentsMargins(4, 4, 4, 4); self.esc.setWidget(self.ebox); el_l.addWidget(self.esc, 1)
        el_b = QHBoxLayout(); el_b.addStretch(1); el_b.addWidget(_icon_btn(("document-save-all", "document-save"), "💾", "Save All Env Assignments", lambda: self._save_sc("env"))); el_l.addLayout(el_b); el.addLayout(el_l, 2)
        el_r = QVBoxLayout(); eb = QHBoxLayout(); self.en_in = QLineEdit(); self.en_in.setPlaceholderText("profile.conf"); eb.addWidget(self.en_in)
        for ic, fb, t, fn in ((("document-new", "list-add"), "+", "New Env Profile", self._env_new), (("document-save",), "💾", "Save Env Profile", self._env_save), (("edit-delete", "user-trash"), "🗑", "Delete Env Profile", self._env_del), (("edit-undo", "document-revert"), "↩", "Restore Deleted Env Profile", self._env_rollback_qt)): eb.addWidget(_icon_btn(ic, fb, t, fn))
        el_r.addLayout(eb); self.eed = QPlainTextEdit(); el_r.addWidget(self.eed, 1); el.addLayout(el_r, 3); self.nb.addTab(ew, "Environment")
        kw_w = QWidget(); kw_outer = QVBoxLayout(kw_w); self.kw_box = QWidget(); self.kw_l = QHBoxLayout(self.kw_box); self.kw_l.setSpacing(6); kw_outer.addWidget(self.kw_box); kw_outer.addStretch(1); self.nb.addTab(kw_w, "Keywords")
        self._init_extra_tabs()

    def _init_extra_tabs(self) -> None:
        pw = QWidget(); p_outer = QVBoxLayout(pw); p_tabs = QTabWidget(); p_outer.addWidget(p_tabs, 1)
        pv = QWidget(); pvl = QVBoxLayout(pv); p_top = QHBoxLayout()
        gb_act = QGroupBox("Active"); l_act = QHBoxLayout(gb_act); l_act.setContentsMargins(6, 4, 6, 4)
        self.pat_cb = QComboBox(); self.pat_cb.setMaximumWidth(200); self.pat_cb.currentIndexChanged.connect(self._pat_load)
        l_act.addWidget(self.pat_cb); l_act.addWidget(_icon_btn(("document-new", "list-add"), "+", "Create Patch", self._create_patch_qt)); l_act.addWidget(_icon_btn(("archive-insert", "edit-cut"), "⏸", "Hold (Remove) Patch", self._remove_patch_qt))
        gb_hld = QGroupBox("Held"); l_hld = QHBoxLayout(gb_hld); l_hld.setContentsMargins(6, 4, 6, 4)
        self.held_cb = QComboBox(); self.held_cb.setMaximumWidth(200)
        l_hld.addWidget(self.held_cb); l_hld.addWidget(_icon_btn(("edit-undo", "document-revert"), "↩", "Restore Held Patch", self._restore_patch_qt)); l_hld.addWidget(_icon_btn(("edit-delete", "delete"), "🗑", "Delete Held Patch", self._delete_patch_qt))
        self.pat_cmt = QCheckBox("#"); self.pat_cmt.setToolTip("Show comments"); self.pat_cmt.toggled.connect(self._pat_load)
        p_top.addWidget(gb_act); p_top.addWidget(gb_hld); p_top.addStretch(1); p_top.addWidget(self.pat_cmt); pvl.addLayout(p_top)
        self.pat_ed = QPlainTextEdit(); self.pat_ed.setReadOnly(True); DiffHighlighter(self.pat_ed.document()); pvl.addWidget(self.pat_ed, 1); p_tabs.addTab(pv, "Patch Viewer")
        self.pat_bk_list, self.pat_bk_diff = self._make_diff_pane(p_tabs, self._pat_bk_sel); self.nb.addTab(pw, "Patches")
        mc_w = QWidget(); mc_v = QVBoxLayout(mc_w); mc_tabs = QTabWidget(); mc_v.addWidget(mc_tabs, 1)
        mce = QWidget(); mcel = QVBoxLayout(mce); self.mc_ed = QPlainTextEdit(); MakeConfHighlighter(self.mc_ed.document()); mcel.addWidget(self.mc_ed, 1)
        mbar = QHBoxLayout(); mbar.addStretch(1)
        self.chk_key = QCheckBox("Protect signing keys"); self.chk_key.setChecked(True); self.chk_key.toggled.connect(self._tog_key)
        self.chk_cmt = QCheckBox("#"); self.chk_cmt.setToolTip("Show comments"); self.chk_cmt.toggled.connect(lambda _: self._ref_mc()); self.mc_ed.textChanged.connect(self._mc_chg)
        mbar.addWidget(self.chk_key); mbar.addWidget(self.chk_cmt); mbar.addWidget(_icon_btn(("document-save",), "💾", "Save make.conf", lambda: self._save_sc("mc")))
        mcel.addLayout(mbar); mc_tabs.addTab(mce, "Editor"); self.mc_bk_list, self.mc_bk_diff = self._make_diff_pane(mc_tabs, self._mc_bk_sel); self.nb.addTab(mc_w, "make.conf")
        bw = QWidget(); bl = QVBoxLayout(bw); bh = QHBoxLayout()
        self.mon_auto = QCheckBox("Auto-refresh (2s)"); self.mon_auto.setChecked(True)
        bh.addWidget(self.mon_auto)
        bh.addStretch(1); bh.addWidget(_icon_btn(("view-refresh", "reload"), "↻", "Refresh Now", self._ref_mon)); bl.addLayout(bh)
        self.mon_ed = QPlainTextEdit(); self.mon_ed.setReadOnly(True); bl.addWidget(self.mon_ed, 1); self.nb.addTab(bw, "Build Monitor")
        self._init_kernel_tab()
        self.mon_tmr = QTimer(self); self.mon_tmr.timeout.connect(lambda: self._ref_mon() if self.mon_auto.isChecked() and self.nb.currentIndex() == 5 else None); self.mon_tmr.start(2000)
        QShortcut(QKeySequence("Ctrl+S"), self, self._save); QShortcut(QKeySequence("Ctrl+Q"), self, self.close); QShortcut(QKeySequence("F5"), self, self._reload)
        self._apply_ui_style(); self._ref_mc(); self._tree(); self._ref_mon()

    def _make_diff_pane(self, tabs: QTabWidget, on_sel) -> tuple[QListWidget, QPlainTextEdit]:
        w = QWidget(); sp = QSplitter(Qt.Orientation.Horizontal); vl = QVBoxLayout(w); vl.addWidget(sp, 1)
        lw = QListWidget(); lw.currentItemChanged.connect(on_sel); sp.addWidget(lw)
        ed = QPlainTextEdit(); ed.setReadOnly(True); DiffHighlighter(ed.document()); sp.addWidget(ed)
        sp.setSizes([260, 640]); tabs.addTab(w, "Backups / Diff"); return lw, ed
    def _init_kernel_tab(self) -> None:
        kw = QWidget(); kl = QVBoxLayout(kw); kl.addWidget(QLabel(kernel_summary()))
        sp = QSplitter(Qt.Orientation.Horizontal); kl.addWidget(sp, 1)
        self.k_list = QListWidget(); self.k_list.currentItemChanged.connect(self._k_load); sp.addWidget(self.k_list)
        rw = QWidget(); rl = QVBoxLayout(rw); kb = QHBoxLayout()
        self.k_name = QLineEdit(); self.k_name.setPlaceholderText("snippet.config"); kb.addWidget(self.k_name, 1)
        for ic, fb, t, fn in ((("document-new", "list-add"), "+", "New Kernel Snippet", self._k_new), (("document-save",), "💾", "Save Kernel Snippet", self._k_save), (("edit-delete", "delete"), "🗑", "Delete Kernel Snippet", self._k_del)): kb.addWidget(_icon_btn(ic, fb, t, fn))
        rl.addLayout(kb); self.k_ed = QPlainTextEdit(); MakeConfHighlighter(self.k_ed.document()); rl.addWidget(self.k_ed, 1)
        sp.addWidget(rw); sp.setSizes([260, 640]); self.nb.addTab(kw, "Kernel Config"); self._k_refresh()
    def _k_refresh(self) -> None:
        self.k_list.clear()
        for p in list_kernel_snippets(): self.k_list.addItem(p.name)
    def _k_load(self, cur, _=None) -> None:
        if not cur: return
        self.active_kcfg = cur.text(); self.k_name.setText(self.active_kcfg); f = KERNEL_CFG_DIR / self.active_kcfg
        self.k_ed.setPlainText(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
    def _k_new(self) -> None: self.active_kcfg = ""; self.k_name.setText("custom.config"); self.k_ed.setPlainText("CONFIG_EXPERT=y\n")
    def _k_save(self) -> None:
        fn = Path(self.k_name.text().strip()).name
        if not fn: return
        fn = fn if fn.endswith(".config") else f"{fn}.config"; dst = KERNEL_CFG_DIR / fn
        if dst.is_file(): rotate_backup(self.store._base(), dst, f"kcfg-{fn}")
        write_one(KERNEL_CFG_DIR, fn, self.k_ed.toPlainText()); self._k_refresh()
    def _k_del(self) -> None:
        if self.active_kcfg: (KERNEL_CFG_DIR / self.active_kcfg).unlink(missing_ok=True); self.active_kcfg = ""; self.k_name.clear(); self.k_ed.clear(); self._k_refresh()
    def _save_ui_cfg(self) -> None:
        cp = _ui_cfg_path(); cp.parent.mkdir(parents=True, exist_ok=True)
        cp.write_text(json.dumps({"ui_dark": self.act_dark.isChecked(), "ui_font_family": self.ui_font.family(), "ui_font_size": self.ui_font.pointSize()}), encoding="utf-8")
    def _apply_ui_style(self) -> None:
        app = QApplication.instance()
        if not app: return
        app.setFont(self.ui_font); self.setFont(self.ui_font)
        dark = self.act_dark.isChecked()
        QIcon.setThemeName("breeze-dark" if dark else "breeze"); QIcon.setFallbackThemeName("breeze")
        self.act_dark.setText("Switch to Light Theme" if dark else "Switch to Dark Theme")
        self.act_dark.setIcon(QIcon.fromTheme("weather-clear" if dark else "weather-clear-night"))
        fg = QColor("#eff0f1" if dark else "#232629")
        bg = QColor("#232629" if dark else "#eff0f1")
        pal = app.style().standardPalette()
        for grp in (QPalette.ColorGroup.Active, QPalette.ColorGroup.Inactive):
            pal.setColor(grp, QPalette.ColorRole.Window, bg)
            pal.setColor(grp, QPalette.ColorRole.WindowText, fg)
            pal.setColor(grp, QPalette.ColorRole.Button, QColor("#31363b" if dark else "#e3e5e7"))
            pal.setColor(grp, QPalette.ColorRole.ButtonText, fg)
            pal.setColor(grp, QPalette.ColorRole.Base, QColor("#181a1f" if dark else "#ffffff"))
            pal.setColor(grp, QPalette.ColorRole.Text, fg)
            pal.setColor(grp, QPalette.ColorRole.Highlight, QColor("#3daee9"))
            pal.setColor(grp, QPalette.ColorRole.HighlightedText, QColor("#ffffff"))
        app.setPalette(pal)
        fg_hex, bg_hex = fg.name(), bg.name()
        base_hex = "#181a1f" if dark else "#ffffff"
        brd_hex = "#3daee9" if dark else "#bdc3c7"
        app.setStyleSheet(
            f"QMenuBar {{ background-color: {bg_hex}; color: {fg_hex}; border-bottom: 1px solid {brd_hex}; padding: 2px; }}"f"QMenuBar::item {{ background: transparent; padding: 4px 10px; border-radius: 4px; }}"f"QMenu {{ background-color: {bg_hex}; color: {fg_hex}; border: 1px solid {brd_hex}; padding: 4px; }}"f"QMenu::item {{ padding: 6px 24px 6px 12px; border-radius: 4px; }}"
            f"QMenuBar::item:selected, QMenu::item:selected {{ background-color: #3daee9; color: #ffffff; }}"
            f"QPlainTextEdit, QLineEdit, QListWidget, QTreeWidget, QComboBox {{ background-color: {base_hex}; color: {fg_hex}; border: 1px solid {brd_hex}; }}"
            f"QGroupBox {{ color: {fg_hex}; border: 1px solid {brd_hex}; margin-top: 6px; padding-top: 6px; }}"
            f"QGroupBox::title {{ subcontrol-origin: margin; left: 8px; padding: 0 3px; }}"
        )
    def _mon_theme(self, _: bool) -> None:
        self._apply_ui_style(); self._save_ui_cfg()
    def _mon_font_pick(self) -> None:
        font, ok = QFontDialog.getFont(self.ui_font, self, "Select Application Font")
        if ok: self.ui_font = font; self._apply_ui_style(); self._save_ui_cfg()
    def _ref_mon(self) -> None: self.mon_ed.setPlainText(read_build_monitor())
    def _clr(self, lay) -> None:
        while lay.count():
            it = lay.takeAt(0)
            if it.widget(): it.widget().deleteLater()
    def _tree(self) -> None:
        self.tree.clear(); q = self.q_in.text().strip().lower(); by_c = {}
        for p in self.store.state.get("packages", ()): by_c.setdefault(p.get("cat"), []).append(p)
        for cat in sorted(by_c):
            ms = [p for p in by_c.get(cat, ()) if not q or q in p.get("cp", "").lower()]
            if not ms: continue
            top = QTreeWidgetItem([f"{cat} ({len(ms)})"]); self.tree.addTopLevelItem(top); top.setExpanded(bool(q))
            for p in ms: ch = QTreeWidgetItem([p.get("name")]); ch.setData(0, Qt.ItemDataRole.UserRole, p.get("cp")); top.addChild(ch)

    def _sel(self) -> None:
        its = self.tree.selectedItems(); cp = its.__getitem__(0).data(0, Qt.ItemDataRole.UserRole) if its else None
        if not cp: return
        self.cur_pkg = self.store.pkg_map.get(cp); self.hdr.setText(f"{self.cur_pkg.get('cpv')}   |   Last merge: {self.cur_pkg.get('build_fmt')}")
        self._use(); self._env(); self._kw(); self._pat()
    def _use(self) -> None:
        self._clr(self.ul_in); p = self.cur_pkg; qf = self.uf.text().strip().lower()
        for f in (p.get("flags", ()) if p else ()):
            fl = f.get("flag")
            if qf and qf not in fl.lower(): continue
            cb = QCheckBox(f"{fl} *" if f.get("forced") else fl); cb.setChecked(bool(p.get("cur_flags", {}).get(fl)))
            cb.toggled.connect(lambda v, k=fl: p.get("cur_flags").update({k: v})); self.ul_in.addWidget(cb)
        self.ul_in.addStretch(1)
    def _env(self) -> None:
        self._clr(self.el_in)
        for e in (self.cur_pkg.get("envs", ()) if self.cur_pkg else ()):
            en = e.get("name"); row = QHBoxLayout(); row.setContentsMargins(2, 0, 2, 0); row.setSpacing(6); cb = QCheckBox(); cb.setChecked(en in self.cur_pkg.get("cur_envs", set()))
            cb.toggled.connect(lambda v, k=en: self.cur_pkg.get("cur_envs").add(k) if v else self.cur_pkg.get("cur_envs").discard(k))
            b = QPushButton(en); b.setFlat(True); b.setStyleSheet("QPushButton { text-align: left; padding: 2px 4px; border: none; } QPushButton:hover { color: #3daee9; }"); b.clicked.connect(lambda _, k=en: self._env_load(k))
            row.addWidget(cb); row.addWidget(b, 1); w = QWidget(); w.setLayout(row); self.el_in.addWidget(w)
        self.el_in.addStretch(1)
    def _env_dir(self) -> Path: return ENV_PROFILES_DIR if os.geteuid() == 0 else (Path.cwd() / "portage-preview" / "env")
    def _env_load(self, fn: str) -> None:
        self.active_env = fn; self.en_in.setText(fn); f = self._env_dir() / fn; f = f if f.is_file() else (ENV_PROFILES_DIR / fn)
        self.eed.setPlainText(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "")
    def _env_new(self) -> None:
        raw = Path(self.en_in.text().strip()).name
        fn = (raw if raw.endswith(".conf") else f"{raw}.conf") if raw else "custom.conf"
        d = self._env_dir(); i = 2
        while (d / fn).exists(): fn = f"custom-{i}.conf"; i += 1
        body = 'MAKEOPTS="-j8 -l8"\n'
        write_one(d, fn, body); self._reload(); self._env_load(fn)
    def _env_save(self) -> None:
        fn = Path(self.en_in.text().strip()).name
        if fn: write_one(self._env_dir(), fn if fn.endswith(".conf") else f"{fn}.conf", self.eed.toPlainText()); self._reload()
    def _env_del(self) -> None:
        if not self.active_env: return
        refs = [cp for _, cp in find_env_refs(self.store._base(), self.active_env)]
        msg = f"Delete '{self.active_env}'?\n\n" + (f"Will automatically remove from {len(refs)} package(s):\n" + "\n".join(f"  • {c}" for c in refs[:20]) if refs else "No packages currently reference this profile.") + "\n\n(A rollback snapshot will be saved automatically.)"
        if QMessageBox.warning(self, "Confirm Cascading Env Delete", msg, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes: return
        res = cascade_delete_env(self.store._base(), self.active_env)
        self.active_env = ""; self.en_in.clear(); self.eed.clear(); self._reload()
    def _env_rollback_qt(self) -> None:
        snaps = list_env_rollbacks(self.store._base())
        if not snaps: QMessageBox.information(self, "Rollback Env Profile", "No deleted environment snapshots available."); return
        if not ok or not pick: return
        msg = apply_env_rollback(next(s for s in snaps if s.name == pick))
        self._reload(); QMessageBox.information(self, "Rollback Complete", msg)
    def _kw(self) -> None:
        self._clr(self.kw_l); p = self.cur_pkg
        if not p: return
        cur_k = next((k for k in ("**", "~amd64", "amd64") if p.get("cur_kw", {}).get(k)), "NONE")
        cb_k = QComboBox(); cb_k.setMaximumWidth(115)
        for t, v in (("(none)", "NONE"), ("amd64", "amd64"), ("~amd64", "~amd64"), ("**", "**")): cb_k.addItem(t, v)
        cb_k.setCurrentIndex(max(0, cb_k.findData(cur_k)))
        cb_k.currentIndexChanged.connect(lambda _: p.update({"cur_kw": {x: (x == cb_k.currentData()) for x in ("amd64", "~amd64", "**")}}))
        cb_s = QComboBox(); cb_s.setMaximumWidth(135)
        for t, v in (("All", "ALL"), ("Exact (=)", "EQ"), ("Forward (>=)", "FWD")): cb_s.addItem(t, v)
        cb_s.setCurrentIndex(max(0, cb_s.findData(p.get("cur_kw_mode", "ALL"))))
        cb_s.currentIndexChanged.connect(lambda _: p.update({"cur_kw_mode": cb_s.currentData()}))
        cur_st = f"M_{p.get('cur_mask')}" if p.get("cur_mask", "NONE") != "NONE" else (f"U_{p.get('cur_unmask')}" if p.get("cur_unmask", "NONE") != "NONE" else "NONE")
        cb_st = QComboBox(); cb_st.setMaximumWidth(135)
        for t, v in (("Normal", "NONE"), ("Mask All", "M_ALL"), ("Mask (=)", "M_EQ"), ("Mask (>=)", "M_FWD"), ("Unmask All", "U_ALL"), ("Unmask (=)", "U_EQ"), ("Unmask (>=)", "U_FWD")): cb_st.addItem(t, v)
        cb_st.setCurrentIndex(max(0, cb_st.findData(cur_st)))
        def _set_st(_=None):
            v = cb_st.currentData()
            p["cur_mask"] = v if v.startswith("M_") else "NONE"
            p["cur_unmask"] = v if v.startswith("U_") else "NONE"
        cb_st.currentIndexChanged.connect(_set_st)
        def _clr_st():
            cb_st.setCurrentIndex(0); p["cur_mask"] = "NONE"; p["cur_unmask"] = "NONE"
        for lbl, w in (("Keyword:", cb_k), ("Scope:", cb_s), ("State:", cb_st)):
            self.kw_l.addWidget(QLabel(lbl)); self.kw_l.addWidget(w)
        self.kw_l.addWidget(_icon_btn(("edit-clear", "edit-delete"), "✕", "Clear Mask / Unmask State", _clr_st))
        self.kw_l.addWidget(_icon_btn(("document-save",), "💾", "Save Keywords", lambda: self._save_sc("kw")))
        self.kw_l.addStretch(1)
    def _cur_pt(self):
        bn = self.pat_cb.currentData()
        return next((x for x in (self.cur_pkg.get("patches", ()) if self.cur_pkg else ()) if x.get("base_name") == bn), None)
    def _pat(self) -> None:
        self.pat_cb.blockSignals(True); self.pat_cb.clear()
        pts = self.cur_pkg.get("patches", ()) if self.cur_pkg else ()
        for pt in pts: self.pat_cb.addItem(pt.get("base_name"), pt.get("base_name"))
        if not pts: self.pat_cb.addItem("No patches", "NONE")
        self.pat_cb.blockSignals(False); self.held_cb.clear()
        held = list(reversed(list_trashed_patches(self.store._base(), self.cur_pkg.get("cp")))) if self.cur_pkg else []
        for hp in held: self.held_cb.addItem(hp.name, str(hp))
        if not held: self.held_cb.addItem("No held patches", "NONE")
        self._pat_load(); self._ref_pat_bk()
    def _pat_load(self) -> None:
        pt = self._cur_pt(); self.pat_ed.clear()
        if not pt: return
        raw = Path(pt.get("path")).read_text(encoding="utf-8", errors="ignore") if Path(pt.get("path")).is_file() else ""
        self.pat_ed.setPlainText(filter_make_conf(raw, self.pat_cmt.isChecked(), False))

    def _create_patch_qt(self) -> None:
        if not self.cur_pkg: return
        dlg = QDialog(self); dlg.setWindowTitle("Create Diff Patch"); dlg.resize(520, 180); vl = QVBoxLayout(dlg)
        o_in = QLineEdit(); m_in = QLineEdit(); n_in = QLineEdit(f"{Path(self.cur_pkg.get('cpv', 'custom')).name}-{int(time.time())}.patch")
        for lbl, box in (("Original:", o_in), ("Modified:", m_in)):
            r = QHBoxLayout(); r.addWidget(QLabel(lbl)); r.addWidget(box, 1)
            r.addWidget(_compact_btn("File...", lambda _, b=box: b.setText(QFileDialog.getOpenFileName(dlg, "File")[0] or b.text())))
            r.addWidget(_compact_btn("Folder...", lambda _, b=box: b.setText(QFileDialog.getExistingDirectory(dlg, "Folder") or b.text()))); vl.addLayout(r)
        nr = QHBoxLayout(); nr.addWidget(QLabel("Name:")); nr.addWidget(n_in, 1); vl.addLayout(nr)
        br = QHBoxLayout(); br.addStretch(1); br.addWidget(_compact_btn("Create", dlg.accept)); br.addWidget(_compact_btn("Cancel", dlg.reject)); vl.addLayout(br)
        if dlg.exec() != QDialog.DialogCode.Accepted: return
        try:
            cp = self.cur_pkg.get("cp"); dst = generate_diff_patch(o_in.text(), m_in.text(), self.store._base() / "patches" / cp, n_in.text())
            rotate_backup(self.store._base(), dst, f"patch-{cp.replace('/', '_')}-{dst.name}")
            self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True})
            self._pat(); self.pat_cb.setCurrentIndex(max(0, self.pat_cb.findData(dst.name)))
        except Exception as exc: QMessageBox.warning(self, "Diff Error", str(exc))
    def _restore_patch_qt(self) -> None:
        if not self.cur_pkg or self.held_cb.currentData() in (None, "NONE"): return
        src = Path(self.held_cb.currentData()); cp = self.cur_pkg.get("cp")
        if QMessageBox.question(self, "Confirm Restore", f"Restore held patch '{src.name}' to active patches?") != QMessageBox.StandardButton.Yes: return
        dst = restore_trashed_patch(self.store._base(), cp, src)
        self.cur_pkg.setdefault("patches", []).append({"base_name": dst.name, "path": str(dst), "enabled": True}); self._pat()
    def _remove_patch_qt(self) -> None:
        pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        if QMessageBox.question(self, "Hold Patch", f"Move '{pt.get('base_name')}' to held stash?") != QMessageBox.StandardButton.Yes: return
        rotate_backup(self.store._base(), Path(pt.get("path")), f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}")
        trash_or_delete_patch(self.store._base(), self.cur_pkg.get("cp"), pt, True)
        self.cur_pkg["patches"] = [x for x in self.cur_pkg.get("patches", ()) if x is not pt]; self._pat()
    def _delete_patch_qt(self) -> None:
        if not self.cur_pkg or self.held_cb.currentData() in (None, "NONE"): return
        src = Path(self.held_cb.currentData())
        if QMessageBox.question(self, "Delete Permanently", f"Permanently delete held patch '{src.name}'?") != QMessageBox.StandardButton.Yes: return
        src.unlink(missing_ok=True); self._pat()
    def _ref_mc(self) -> None:
        self.mc_ed.blockSignals(True); self.mc_ed.setPlainText(filter_make_conf(self.store.cur_mc, self.chk_cmt.isChecked(), self.chk_key.isChecked())); self.mc_ed.blockSignals(False); self._ref_mc_bk()
    def _tog_key(self, v: bool) -> None:
        if v: self._ref_mc(); return
        ans, ok = QInputDialog.getText(self, "Unlock Signing Keys", "Type capital YES to unlock:")
        if ok and ans.strip() == "YES": self._ref_mc()
        else: self.chk_key.blockSignals(True); self.chk_key.setChecked(True); self.chk_key.blockSignals(False)
    def _mc_chg(self) -> None:
        if not self.chk_cmt.isChecked(): return
        if not self.chk_key.isChecked(): self.store.cur_mc = self.mc_ed.toPlainText()
        else:
            kept = [ln for ln in self.store.cur_mc.splitlines() if any(ln.strip().startswith(f"{k}=") for k in PROTECTED_KEYS)]
            self.store.cur_mc = "\n".join(kept + self.mc_ed.toPlainText().splitlines())

    def _ref_mc_bk(self) -> None:
        self.mc_bk_list.clear()
        for p in list_backups(self.store._base(), "make.conf"): self.mc_bk_list.addItem(p.name)
    def _mc_bk_sel(self, cur, _=None) -> None:
        if not cur: return
        f = self.store._base() / ".gentoolcfg-backups" / cur.text()
        old_t = filter_make_conf(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "", self.chk_cmt.isChecked(), self.chk_key.isChecked())
        cur_t = filter_make_conf(self.store.cur_mc, self.chk_cmt.isChecked(), self.chk_key.isChecked())
        self.mc_bk_diff.setPlainText(unified_diff_lines(old_t, cur_t, cur.text(), "current make.conf"))
    def _ref_pat_bk(self) -> None:
        self.pat_bk_list.clear(); pt = self._cur_pt()
        if not pt or not self.cur_pkg: return
        for p in list_backups(self.store._base(), f"patch-{self.cur_pkg.get('cp').replace('/', '_')}-{pt.get('base_name')}"): self.pat_bk_list.addItem(p.name)
    def _pat_bk_sel(self, cur, _=None) -> None:
        pt = self._cur_pt()
        if not cur or not pt: return
        f = self.store._base() / ".gentoolcfg-backups" / cur.text()
        self.pat_bk_diff.setPlainText(unified_diff_lines(f.read_text(encoding="utf-8", errors="ignore") if f.is_file() else "", self.pat_ed.toPlainText(), cur.text(), pt.get("base_name")))
    def _reload(self) -> None: self.store = CfgStore(); self._ref_mc(); self._tree(); self._ref_mon()
    def _save_sc(self, sc: str) -> None:
        chg = self.store.save_scope(sc, self.cur_pkg)
        if not chg: QMessageBox.information(self, "No Changes", "No pending changes in this tab."); return
        self._tree(); self._ref_mc_bk(); QMessageBox.information(self, "Saved", "Saved:\n" + "\n".join(chg))
    def _save(self) -> None:
        idx = self.nb.currentIndex()
        if idx in (0, 1, 2, 4): self._save_sc({0: "use", 1: "env", 2: "kw", 4: "mc"}[idx])

    def _on_top_tab(self, idx: int) -> None:
        if idx != 1 or self.qp_embedded: return
        qp_bin = "/usr/bin/qparted"
        if not Path(qp_bin).is_file():
            self.qp_status.setText("QParted (/usr/bin/qparted) is not installed."); return
        self.qp_status.setText("Starting embedded QParted...")
        env = dict(os.environ); env["QT_QPA_PLATFORM"] = "xcb"
        self.qp_proc = subprocess.Popen([qp_bin], env=env)
        QTimer.singleShot(900, self._attach_qparted)

    def _attach_qparted(self) -> None:
        if not self.qp_proc or self.qp_embedded: return
        res = subprocess.run(["xwininfo", "-root", "-tree"], capture_output=True, text=True)
        wid = None
        for ln in res.stdout.splitlines():
            if "QParted" in ln and (m := re.search(r"0x[0-9a-fA-F]+", ln)):
                wid = int(m.group(0), 16); break
        if not wid:
            QTimer.singleShot(500, self._attach_qparted); return
        win = QWindow.fromWinId(wid)
        cont = QWidget.createWindowContainer(win, self.qp_tab)
        self.qp_status.hide(); self.qp_lay.addWidget(cont, 1); self.qp_embedded = True

    def closeEvent(self, ev) -> None:
        if self.qp_proc and self.qp_proc.poll() is None: self.qp_proc.terminate()
        super().closeEvent(ev)

def main() -> None:
    if os.geteuid() != 0:
        disp = os.environ.get("DISPLAY", ":0")
        xauth = os.environ.get("XAUTHORITY", str(Path.home() / ".Xauthority"))
        os.system(f"xhost +SI:localuser:root >/dev/null 2>&1")
        os.execvp("pkexec", ["pkexec", "env", f"DISPLAY={disp}", f"XAUTHORITY={xauth}", "QT_QPA_PLATFORM=xcb", "/usr/bin/gentoolcfg-qt6", *sys.argv[1:]])
    try:
        ensure_gentoo_os()
        app = QApplication(sys.argv); w = GentoolCfgQt(); w.show(); sys.exit(app.exec())
    except RuntimeError as exc:
        raise SystemExit(f"ERROR: {exc}")
