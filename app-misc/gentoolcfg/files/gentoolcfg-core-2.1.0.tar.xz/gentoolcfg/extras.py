import difflib, os, re, subprocess
from pathlib import Path

KERNEL_CFG_DIR = Path("/etc/kernel/config.d")

def list_backups(base_dir: Path, prefix: str) -> list[Path]:
    bdir = base_dir / ".gentoolcfg-backups"
    if not bdir.is_dir(): return []
    return sorted((p for p in bdir.glob(f"{prefix}*") if p.is_file()), reverse=True)[:10]

def unified_diff_lines(old_text: str, new_text: str, old_lbl: str, new_lbl: str) -> str:
    diff = list(difflib.unified_diff(
        old_text.splitlines(), new_text.splitlines(), fromfile=old_lbl, tofile=new_lbl, lineterm=""
    ))
    return "\n".join(diff) if diff else "(No differences between selected backup and current file)"

def read_build_monitor() -> str:
    out = []
    ps = subprocess.run(["pgrep", "-af", "emerge|ninja|cargo|make"], capture_output=True, text=True)
    procs = [ln for ln in ps.stdout.splitlines() if "gentoolcfg" not in ln][:8]
    out.append("=== ACTIVE BUILD PROCESSES ===")
    out.extend(procs if procs else ["(No active emerge/compiler processes)"])
    elog = Path("/var/log/emerge.log")
    if elog.is_file():
        out.append("\n=== RECENT EMERGE LOG ===")
        out.extend(elog.read_text(encoding="utf-8", errors="ignore").splitlines()[-15:])
    logs = sorted(Path("/var/tmp/portage").glob("*/*/temp/build.log"), key=lambda p: p.stat().st_mtime, reverse=True)
    if logs:
        out.append(f"\n=== LATEST BUILD LOG: {logs[0]} ===")
        out.extend(logs[0].read_text(encoding="utf-8", errors="ignore").splitlines()[-25:])
    return "\n".join(out)

def list_kernel_snippets() -> list[Path]:
    return sorted(KERNEL_CFG_DIR.glob("*.config")) if KERNEL_CFG_DIR.is_dir() else []

def kernel_summary() -> str:
    rel = os.uname().release
    src = Path("/usr/src/linux")
    tgt = str(src.resolve()) if src.exists() else "(not linked)"
    return f"Running Kernel: {rel}   |   /usr/src/linux -> {tgt}"

def detect_drm_modes() -> list[str]:
    modes = []
    for mf in sorted(Path("/sys/class/drm").glob("card*-*/modes")):
        for ln in mf.read_text(encoding="utf-8", errors="ignore").splitlines():
            if re.match(r"^\d+x\d+", ln) and ln not in modes: modes.append(ln)
    return modes or ["1920x1080", "1280x800", "1024x768"]

def apply_tty_resolution(mode: str) -> str:
    if os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY"):
        return f"GUI session detected; saved preferred TUI mode {mode}"
    m = re.match(r"^(\d+)x(\d+)", mode)
    if not m: return "Invalid mode"
    w, h = m.group(1), m.group(2)
    res = subprocess.run(["fbset", "-g", w, h, w, h, "32"], capture_output=True, text=True)
    return f"TTY framebuffer set to {w}x{h}" if res.returncode == 0 else (res.stderr.strip() or "fbset unavailable")

def find_env_refs(base_dir: Path, fname: str) -> list[tuple[Path, str]]:
    pe = base_dir / "package.env"
    if not pe.exists(): return []
    files = [pe] if pe.is_file() else [p for p in sorted(pe.rglob("*")) if p.is_file() and not p.name.startswith(".")]
    hits = []
    for f in files:
        for raw in f.read_text(encoding="utf-8", errors="ignore").splitlines():
            toks = raw.strip().split()
            if len(toks) >= 2 and not toks[0].startswith("#") and fname in toks[1:]:
                hits.append((f, toks[0]))
    return hits

def cascade_delete_env(base_dir: Path, fname: str) -> dict:
    import json
    from datetime import datetime
    rb_dir = base_dir / ".gentoolcfg-env-rollback"; rb_dir.mkdir(parents=True, exist_ok=True)
    env_f = base_dir / "env" / fname
    snap = {"fname": fname, "env_text": env_f.read_text(encoding="utf-8", errors="ignore") if env_f.is_file() else "", "files": {}}
    pe = base_dir / "package.env"
    files = [pe] if pe.is_file() else ([p for p in sorted(pe.rglob("*")) if p.is_file() and not p.name.startswith(".")] if pe.is_dir() else [])
    affected = []
    for f in files:
        orig = f.read_text(encoding="utf-8", errors="ignore")
        out, changed = [], False
        for raw in orig.splitlines():
            toks = raw.strip().split()
            if len(toks) >= 2 and not toks[0].startswith("#") and fname in toks[1:]:
                changed = True; affected.append(toks[0])
                rem = [t for t in toks[1:] if t != fname]
                if rem: out.append(f"{toks[0]} {' '.join(rem)}")
            else: out.append(raw)
        if changed:
            snap["files"][str(f)] = orig
            f.write_text("\n".join(out) + "\n", encoding="utf-8") if out else f.unlink(missing_ok=True)
    env_f.unlink(missing_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    (rb_dir / f"{ts}_{fname}.json").write_text(json.dumps(snap, indent=2), encoding="utf-8")
    for old in sorted(rb_dir.glob("*.json"))[:-10]: old.unlink(missing_ok=True)
    return {"fname": fname, "affected": affected}

def list_env_rollbacks(base_dir: Path) -> list[Path]:
    rb = base_dir / ".gentoolcfg-env-rollback"
    return sorted(rb.glob("*.json"), reverse=True) if rb.is_dir() else []

def apply_env_rollback(snap_path: Path) -> str:
    import json
    snap = json.loads(snap_path.read_text(encoding="utf-8"))
    env_f = Path("/etc/portage/env") / snap["fname"]; env_f.parent.mkdir(parents=True, exist_ok=True)
    if snap.get("env_text"): env_f.write_text(snap["env_text"], encoding="utf-8")
    for fpath, content in snap.get("files", {}).items():
        fp = Path(fpath); fp.parent.mkdir(parents=True, exist_ok=True); fp.write_text(content, encoding="utf-8")
    snap_path.unlink(missing_ok=True)
    return f"Restored {snap['fname']} and {len(snap.get('files', {}))} package.env file(s)."
